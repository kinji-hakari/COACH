import React, { useState } from "react";
import styles from "../Navbar/Navbar.module.css";
import { getImageUrl } from "../../utils";
import { Link } from "react-router-dom";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Become from "../../Pages/Become";

export const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <Router>
      <nav className={styles.navbar}>
        <a className={styles.title} href="/">
          <img className={styles.logo} src="/ic.ico" />
          Tech Mentor
        </a>
        <div className={styles.menu}>
          <img
            className={styles.menuBtn}
            src={
              menuOpen
                ? getImageUrl("nav/closeIcon.png")
                : getImageUrl("nav/menuIcon.png")
            }
            alt="menu-button/"
            onClick={() => setMenuOpen(!menuOpen)}
          />
          <ul
            className={`${styles.menuItems} ${menuOpen && styles.menuOpen}`}
            onClick={() => setMenuOpen(false)}
          >
            <li>
              <div>About</div>
            </li>

            <li>
              <Link to="/Become">Become a Coach</Link>
            </li>

            <li>
              <div>Contact</div>
            </li>
            <li>
              <div>FAQ</div>
            </li>
            <li>
              <div className={styles.special}>Members Area</div>
            </li>
          </ul>
        </div>
      </nav>
      <Routes>
        <Route path="/Become" element={<Become />} />
      </Routes>
    </Router>
  );
};
