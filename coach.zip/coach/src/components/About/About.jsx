import React from "react";
import styles from "../About/About.module.css";
import { getImageUrl } from "../../utils";

export const About = () => {
  return (
    <section className={styles.container} id="About">
      <h2 className={styles.title}>About</h2>
      <div className={styles.content}>
        <ul className={styles.aboutItems}>
          <li className={styles.aboutItem}>
            <img src={getImageUrl("about/cursorIcon.png")} alt="cursor icon" />
            <div className={styles.aboutItemsText}>
              <h3>Become a Better Developer!</h3>
              <p>
                Are you passionate about coding and dream of excelling as a
                developer or programmer? Don’t hesitate any longer! If you’re
                serious about enhancing your skills and building a successful
                career in tech, Tech Mentor has the perfect solution for you
              </p>
            </div>
          </li>
          <li className={styles.aboutItem}>
            <img src={getImageUrl("about/serverIcon.png")} alt="server icon" />
            <div className={styles.aboutItemsText}>
              <h3>Our Professionals are ready to help you.</h3>
              <p>
                Our highly skilled mentors are ready to take your coding journey
                to the next level. Whether you’re a beginner just starting out
                or an experienced coder looking to specialize in areas like web
                development, data science, or game development, Tech Mentor
                offers personalized coaching to help you achieve your goals.
              </p>
            </div>
          </li>
          <li className={styles.aboutItem}>
            <img src={getImageUrl("about/uiIcon.png")} alt="ui icon" />
            <div className={styles.aboutItemsText}>
              <h3>Enjoy the Results of the Instant Improvement</h3>
              <p>
                With expert guidance, real-world projects, and a tailored
                approach, you'll gain the skills and confidence to stand out in
                your field. You're just a few clicks away from becoming the
                developer you've always aspired to be. Start your journey with
                Tech Mentor today and unleash your full potential!
              </p>
            </div>
          </li>
        </ul>
      </div>
    </section>
  );
};
