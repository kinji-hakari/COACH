import React from "react";
import styles from "../Contact/Contact.module.css";
import { getImageUrl } from "../../utils";
export const Contact = () => {
  return (
    <footer id="Contact" className={styles.container}>
      <div className={styles.text}>
        <h2>Contact</h2>
        <p>feel free to reach out</p>
      </div>
      <ul className={styles.links}>
        <li className={styles.link}>
          <a href="email@gmail.com">
            <img
              className={styles.img}
              src={getImageUrl("contact/emailIcon.png")}
              alt="Email"
            ></img>
          </a>
        </li>
        <li className={styles.link}>
          <a href="https://www.facebook.com/">
            <img
              className={styles.img}
              src={getImageUrl("contact/f.ico")}
              alt="ficon"
            ></img>
          </a>
        </li>
        <li className={styles.link}>
          <a href="https://www.instagram.com/">
            <img
              className={styles.img}
              src={getImageUrl("contact/i.ico")}
              alt="iicon"
            ></img>
          </a>
        </li>
      </ul>
      <div className={styles.other}>
        © 2025 Tech Mentor. All rights reserved
        <br></br>
        <br></br>
        Terms of use | Privacy Policy | Blog
      </div>
    </footer>
  );
};
