import React, { useState } from "react";
import styles from "./Hero.module.css";

export const Hero = () => {
  // You can add state here to handle input values for the search if needed
  const [searchTerm, setSearchTerm] = useState("");

  // Handle search input change
  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  return (
    <section className={styles.heroSection}>
      <div className={styles.heroContent}>
        <h1>Ready to Take Your Skills up a Notch?</h1>
        <div className={styles.searchContainer}>
          <input
            type="text"
            className={styles.searchInput}
            placeholder="Search by Domain or Coach"
            value={searchTerm}
            onChange={handleSearchChange}
          />
        </div>
        <div className={styles.stepsContainer}>
          <ul className={styles.numberedlist}>
            <li>
              <span className={styles.circles}>1</span> Choose your Domain
            </li>
            <li>
              <span className={styles.circles}>2</span> Find your Coach
            </li>
            <li>
              <span className={styles.circles}>3</span> Start improving
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
};
