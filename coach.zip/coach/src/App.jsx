import Styles from "./App.module.css";
import { Navbar } from "./components/Navbar/Navbar";
import { Hero } from "./components/Hero/Hero";
import { About } from "./components/About/About";
import { Contact } from "./components/Contact/Contact";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Become from "./Pages/Become";
function App() {
  return (
    <div className={Styles.App}>
      <Navbar />
      <Hero />
      <About />
      <Contact />
    </div>
  );
}

export default App;
